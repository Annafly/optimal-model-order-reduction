close all
 clc
 clear all
 example = input('Enter example number: ');
 switch example

 case 1
%EXAMPLE 1 n=11,m=9

%  numerator=[-2.9239 -39.5525 -97.5270 -147.1508];
%  denominator=[1 11.9584 43.9119 73.6759 44.3821];
 numerator=[-2.476 -54.08 -477.3 -1872 -651.4 2.125e4 8.145e4 1.556e5 1.41e5 5.301e4 5869];
 denominator=[1 27.44 430.5 4586 3.271e4 1.47e5 4.017e5 6.841e5 7.574e5 5.313e5 2.03e5 3.089e4];
n=11;
m=6;
% numerator=[-2.924 -39.55 -97.53 -147.2];
%  denominator=[1 11.96 43.91 73.68 44.38];
%  numerator=[0.385 4.683 144.1 -116.3 -82.3];
%  denominator=[1 11.6 252.6 751.1 534 94.56];
% numerator=[1.802 11.05 33.83 69.71 104.6 117.4 101.7 68.01 32.89 10.27 1.766 0.1201];
%  denominator=[1 6.8 23.48 54.89 93.98 121.2 120.4 92.46 53.27 21.7 5.742 0.8652 0.05496];
% numerator=[-0.1463 0.004163 2.325 6.701 6.717 2.325];
%  denominator=[1 4.768 17.53 41.44 46.64 22.95 3.949];
% numerator=[-5.738 -19.65 -25.09 -12.59 -2.002];
%  denominator=[1 3.925 6.088 4.323 1.319 0.1191];
 
%  
%  numerator=[4.899 45.18 167.8 342 407.2 290.1 141.5 40.85];
%  denominator=[1 9.982 43 111.6 195.6 244.6 215.3 114.3 25.91];
% n=5;
% m=3;
sys = tf(numerator,denominator)

 [A,B,C,D] = tf2ss(numerator,denominator);

 case 2
 %EXAMPLE 2 n=16,m=8
% numerator=[-1.2805 -6.2266 -12.8095 -9.3373];
%  denominator=[1 3.1855 8.9263 12.2936 3.1987];
numerator=[4.293 120.7 1965 2.325e04 2.054e05 1.348e06 5.833e06 1.586e07 2.961e07 3.958e07 3.716e07 2.35e07 9.141e06 1.97e06 2.028e05 7030];
 denominator=[1 31.56 588.6 7700 7.171e04 4.875e05 2.303e06 7.317e06 1.592e07 2.373e07 2.366e07 1.576e07 7.183e06 2.201e06 4.137e05 4.004e04 1367];
n=16;
m=7;
 sys = tf(numerator,denominator)

 [A,B,C,D] = tf2ss(numerator,denominator);

 case 3
 %EXAMPLE 3 n=6.m=5
numerator=[-1.552 -14.48 -41.51 -89.29 -87.9 -29];
 denominator=[1 9.359 29.11 83.99 131.2 91.04 22.72];
 n=6;
 m=5;
%  numerator=[-1.3369 -4.8341 -47.5819 -42.7285];
%  denominator=[1 17.0728 84.9908 122.4400 59.9309];

 sys = tf(numerator,denominator)

 [A,B,C,D] = tf2ss(numerator,denominator);
 

 case 4
 %EXAMPLE 4 n=15,m=9

%  A=[0 0 0 -150;
%  1 0 0 -245 ;
%  0 1 0 -113 ;
%  0 0 1 -19 ;];
%  B=[4;1;0;0];
%  C=[0 0 0 1];
% 
% [numerator,denominator] = ss2tf(A,B,C,0);
%  sys = tf(numerator,denominator)

 numerator=[0.7807 -2.599 -292 -4254 -3.461e04 -1.958e05 -8.208e05 -2.604e06 -6.424e06 -1.233e07 -1.726e07 -1.578e07 -8.331e06 -2.233e06 -2.336e05];
 denominator=[1 19.51 322.1 3665 2.782e04 1.539e05 6.51e05 2.115e06 5.264e06 9.999e06 1.42e07 1.431e07 9.476e06 3.722e06 7.664e05 6.295e04];
n=15;
m=5;
 sys = tf(numerator,denominator)

 [A,B,C,D] = tf2ss(numerator,denominator);

 case 5
 %EXAMPLE 5

%  numerator=[1 15 50];
%  denominator=[1 5 33 79 50];

%  numerator=[-1.162 -10.09 -23.78 22.13 182.3 296.6 211 73.21 11.92 0.7073];
%  denominator=[1 15.89 103.4 356.5 705.1 808.3 530.7 196.4 38.95 3.609 0.1069];
 numerator=[-1.175 -9.97 -24.23 21.89 183.2 294.9 212 75.25 12.13 0.6973];
 denominator=[1 16.23 102.7 355.8 704.9 805.9 531.2 194.8 40.12 3.705 0.1123];
n=10;
m=4;
 sys = tf(numerator,denominator)
 [A,B,C,D] = tf2ss(numerator,denominator);

 case 6
 %EXAMPLE 6

%  numerator=[41 50 140];
%  denominator=[1 11 111 110 100];
%  numerator=[-0.007701 3.092 31.97 138.1 149 38.15 0.3429];
%  denominator=[1 10.78 63.22 207.4 602 797.6 415 68.35];
 numerator=[-0.00946 4.23 34.23 140.4 150 34.67 0.4523];
 denominator=[1 11.12 65.15 203.8 605 801.4 413 64.32]; 
n=7;
 m=5;
 
 sys = tf(numerator,denominator)

 [A,B,C,D] = tf2ss(numerator,denominator);
tStart = tic; 
 end
 G=ss(A,B,C,D);
 n=size(A);

tStart = tic; 
 fprintf('Calculate fixed points.... \n')


 [s0,p]=tmp_fixed_points(A,B,C,D,m)

for i=1:p
    Gm= Gm_generate(n,m,G,s0(i,:));
    TT(6)=toc;
    E(i) = Error_calculate(n,G,Gm);
end

[Em,d]=min(E);
Gm= Gm_generate(n,m,G,s0(d,:));
[numerator,denominator] = ss2tf(Gm.A,Gm.B,Gm.C,Gm.D);

 sysm = tf(numerator,denominator)

  bode(G,'r',Gm,'b--')

 tEnd = toc(tStart) 
 
function F = M_solve_system(z,A,B,C,D,m)

n=size(A,2);
m;
%A
O=zeros(n);
I=eye(n);

An=zeros(2*n,2*n,m,m);

for i=1:m
for j=1:m
if i==j
An(:,:,i,j)=[A O;O A];
end
if i+1==j
An(:,:,i,j)=[I O;O O];
end
if i==j+1
An(:,:,i,j)=[O O;O I];
end
end
end

An(:,:,1,1)=[A 2*A;O A]; An(:,:,1,2)=[I O;I O];
An(:,:,2,1)=[O O;I O]; 

ah=[];
AH=[];%% important
for i=1:m
for j=1:m
    ah=[ah,An(:,:,i,j)];
end
 AH=[AH;ah];
 ah=[];
end

%B
Bn=zeros(n,m,m);

for i=1:m
Bn(:,i,i)=B;
end
Bno=zeros(n,m);


bh=[];
BH=[];
bh=[bh;Bn(:,:,1);Bn(:,:,1)];
for i=2:m
    bh=[bh;Bn(:,:,i);Bno];
end
BH=bh;


%C
Cn=zeros(m,n,m);

for i=1:m
Cn(i,:,i)=C;
end
Cno=zeros(m,n);


ch=[];
CH=[];
ch=[ch,Cn(:,:,1),Cno];
for i=2:m
    ch=[ch,Cno,Cn(:,:,i)];
end
CH=ch;

%D
DH=zeros(m,m);

I2N=eye(2*n);
O2N=zeros(2*n);

f=zeros(2*m*n,2*m*n,m);

for i=1:m
f((i-1)*2*n+1:2*n*i,(i-1)*2*n+1:2*n*i,i)=I2N;
end

for i=1:m
S(i)=z(i);
end

size(AH);
size(BH);
size(CH);
size(DH);
size(f);

AHS=zeros(2*m*n,2*m*n,m);
Y=[1:m];
for i=1:m
    AHS(:,:,i)=AH;
for j=1:m
AHS(:,:,i)=AHS(:,:,i)-S(Y(j))*f(:,:,j);
end
F(i)=det([AHS(:,:,i) BH;CH DH]);
Y = circshift(Y,2);
end
end


%%

function [s0,p]=tmp_fixed_points(A,B,C,D,m)

FP_real=[];

tries=200;
r=zeros(tries,m);
options = optimset('Display','off');
for i=1:tries
    x0=zeros(1,m);
    for j=1:m
        x0(j)=rand*10^(randi([0 2]));
    end
    x = fsolve(@(z)M_solve_system(z,A,B,C,D,m),x0,options);
    r(i,:)=x;
end


r=round(r,4);


[U I]=unique(r(:,1),'first');
 FP_real=r(I,:);

for i=1:m
    s(:,i)=FP_real(:,i);
end




positive_reals=true(size(s,1),1);


    for j=1:size(s,1)
        for i=1:m
        if (real(s(j,i))<0)
            positive_reals(j)=false;
        end
    end
    end
    s=s(positive_reals,:)

 FP_real=s;


FP_imaj=[];
%imaginary fixed points

tries=200;
r=zeros(tries,m);
options = optimset('Display','off');
for i=1:tries
    complex=100*rand;
    for j=1:m
        x0(j)=complex*exp(2*j*pi/m*1i);
    end
    x0=cplxpair(x0);
    r(i,:) = fsolve(@(z)M_solve_system(z,A,B,C,D,m),x0,options);
end

r=round(r,4);

[U I]=unique(r(:,1),'first');
FP_imaj=r(I,:);

[theta,rho] = cart2pol(real(FP_imaj),imag(FP_imaj));
theta=rad2deg(theta);
round(sum(theta,2),0);
closed_conj=(mod(sum(theta,2),(180/m))==0);
FP_imaj=FP_imaj(closed_conj,:);

FP=[FP_real;FP_imaj];

s=[];
for i=1:m
    s(:,i)=FP(:,i);
end
 %clearing
comb=combnk(1:m,2);
not_equal=false(size(s,1),1);

for i=1:size(comb,1)
    not_equal=not_equal|(s(:,comb(i,1))==s(:,comb(i,2)));
end

s=s(~not_equal,:);

stable_pairs=true(size(s,1),1);
n=size(A,2);
E=eye(n);
for i=1:size(s,1)
    s0=s;
    G=ss(A,B,C,D);
    Gm= Gm_generate(n,m,G,s0(i,:));
      if (~isstable(Gm))
            stable_pairs(i)=false;
      end
end

s=s(stable_pairs,:);


[U I]=unique(round(sum(s,2),2),'first');
 s0=s(I,:);

p=size(s0,1);
end

%%
function Gm = Gm_generate(n,m,G,sigma)
In=eye(n);
A = G.A;B = G.B;C = G.C;


for i=1:m 
        Vm(:,i)=(sigma(i)*In-A)\B; 
        Wm(:,i)=(conj(sigma(i))*In-A')\C';
 end

Am=(Wm'*Vm)\(Wm'*A*Vm);
Bm=(Wm'*Vm)\(Wm'*B); 
Cm=C*Vm;
Dm=0;
Gm=ss(Am,Bm,Cm,Dm);
end


function E = Error_calculate(n,G,Gm) 
In=eye(n);
A = G.A; B = G.B; C = G.C; D = G.D;
Am = Gm.A; Bm = Gm.B; Cm = Gm.C; Dm = Gm.D; 
H=G-Gm;
AH = H.A; BH = H.B; CH = H.C; DH = H.D; 
PH=lyap(AH,BH*BH');
P=lyap(A,B*B');
Pm=lyap(Am,Bm*Bm');
E= (CH*PH*CH')/(C*P*C');
E=sqrt(E);
end