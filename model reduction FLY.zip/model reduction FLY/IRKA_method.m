function [Gm,iter_no,sigma] = IRKA(n,m,G,s)
In=eye(n);%eye:Identity matrix
Im=eye(m);
A = G.A; B = G.B; C = G.C; D = G.D;
%Assign initiate value of sigma
sigma = s;
%Number of interations in each random search
N = 0;
%Number of random search
R = 0;

flag=1;

%Comparing sigma and eig(-Am) to find local minimizers
while flag==1 && R<=10
    N=N+1;
    for i=1:m 
        Vm(:,i)=(sigma(i)*In-A)\B; 
        Wm(:,i)=(conj(sigma(i))*In-A')\C';
    end
    
    Am=(Wm'*Vm)\(Wm'*A*Vm);
    
    neg_eigAm=eig(-Am);% e = eig(A) returns a column vector containing the eigenvalues of square matrix A.
    neg_eigAm=sort(neg_eigAm);
    sigma=sort(sigma);
    
    E=sigma-neg_eigAm;
    %Check if it is the local min.
    TE = abs(sum(E)/sum(sigma));
    if abs(sum(E)/sum(sigma))<0.005% tolerance error
        flag=0; %satisfied
    else
        sigma=neg_eigAm;%not satisfy / update the sigma
    end
    
    if N>=10000 % many times iteration not satisfy
        R=R+1; 
        sigma=abs(randn(m,1)); %change the initial points
        N = 0;
    end
end

%Construct the local minimizer, Gm
Am = Am; 
Bm=(Wm'*Vm)\(Wm'*B); 
Cm=C*Vm;
Dm=0;
Gm=ss(Am,Bm,Cm,Dm); %sys = ss(A,B,C,D) creates a continuous-time state-space model
iter_no = N;