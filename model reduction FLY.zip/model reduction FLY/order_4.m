close all
 clc
 clear all
 example = input('Enter example number: ');
 switch example

 case 1
%EXAMPLE 1

%  numerator=[-2.9239 -39.5525 -97.5270 -147.1508];
%  denominator=[1 11.9584 43.9119 73.6759 44.3821];
 numerator=[1.587 1.806 1.279 7.381 1.954];
 denominator=[1 3.216 7.547 10.16 4.151 0.5124];

sys = tf(numerator,denominator)

 [A,B,C,D] = tf2ss(numerator,denominator);

 case 2
 %EXAMPLE 2
% numerator=[-1.2805 -6.2266 -12.8095 -9.3373];
%  denominator=[1 3.1855 8.9263 12.2936 3.1987];
numerator=[0.482 5.079 21.66 49.52 94.88 91.75 31.734];
 denominator=[1 8.789 38.11 122.9 253.2 375.4 311.8 94.31];

 sys = tf(numerator,denominator)

 [A,B,C,D] = tf2ss(numerator,denominator);

 case 3
 %EXAMPLE 3
numerator=[0.1001 -5.45 -17.11 73.87 404.1 622.2 393.9 104.9 9.508];
 denominator=[1 12.54 76.51 279.8 608.5 750.6 508 184 32.98 2.246];
 
%  numerator=[-1.3369 -4.8341 -47.5819 -42.7285];
%  denominator=[1 17.0728 84.9908 122.4400 59.9309];

 sys = tf(numerator,denominator)

 [A,B,C,D] = tf2ss(numerator,denominator);
 

 case 4
 %EXAMPLE 4

%  A=[0 0 0 -150;
%  1 0 0 -245 ;
%  0 1 0 -113 ;
%  0 0 1 -19 ;];
%  B=[4;1;0;0];
%  C=[0 0 0 1];
% 
% [numerator,denominator] = ss2tf(A,B,C,0);
%  sys = tf(numerator,denominator)

 numerator=[-2.59 -14.2 -36.63 -57.39 -59.56 -42.79 -21.87 -7.922 -1.827 -0.1961];
 denominator=[1 6.694 21.34 42.07 56.38 53.46 36.27 17.49 5.796 1.185 0.1108];

 sys = tf(numerator,denominator)

 [A,B,C,D] = tf2ss(numerator,denominator);

 case 5
 %EXAMPLE 5

%  numerator=[1 15 50];
%  denominator=[1 5 33 79 50];

%  numerator=[-0.2789 -2.942 -12.79 -29.35 -36.76 -23.5 -5.963];
%  denominator=[1 10.22 44.45 105.7 147.2 119.5 52.19 9.433];
 numerator=[-0.2812 -2.892 -12.45 -30.23 -35.34 -22.9 -5.456];
 denominator=[1 11.23 45.323 104.2 148.3 120.4 51.98 9.543];

 sys = tf(numerator,denominator)
 [A,B,C,D] = tf2ss(numerator,denominator);

 case 6
 %EXAMPLE 5

%  numerator=[41 50 140];
%  denominator=[1 11 111 110 100];
%  numerator=[-1.019 -11.68 -32.26 -0.319 20.58 6.205];
%  denominator=[1 10.85 58.67 201.6 368.7 288 76.5]; 
 numerator=[-2.135 -12.34 -31.98 -0.298 21.23 6.342];
 denominator=[1 11.02 56.43 197.9 356.7 298 77.5];
 sys = tf(numerator,denominator)

 [A,B,C,D] = tf2ss(numerator,denominator);

 end
 G=ss(A,B,C,D);
 n=size(A);

 tic
 fprintf('Calculate fixed points.... \n')

 [s0,m]=fixed_points(A,B,C,D)

for i=1:m
    Gm= Gm_generate(n,G,s0(i,:));
    E(i) = Error_calculate(n,G,Gm);
end
[Em,d]=min(E);
Gm= Gm_generate(n,G,s0(d,:));

[numerator,denominator] = ss2tf(Gm.A,Gm.B,Gm.C,Gm.D);

 sysm = tf(numerator,denominator)

bode(G,'r',Gm,'b--')

 toc
 
 function F = solve_system(z,A,B,C,D)

 n=size(A,2);

 O=zeros(n);
 I=eye(n);
 A11=[A 2*A;O A]; A12=[I O;I O]; A13=[O O;O O]; A14=[O O;O O];
 A21=[O O;I O]; A22=[A O;O A]; A23=[I O;O O]; A24=[O O;O O];
A31=[O O;O O]; A32=[O O;O I]; A33=[A O;O A]; A34=[I O;O O];
A41=[O O;O O]; A42=[O O;O O]; A43=[O O;O I]; A44=[A O;O A];

O=zeros(size(B));

B1=[B O O O;B O O O];
B2=[O B O O;O O O O];
B3=[O O B O;O O O O];
B4=[O O O B;O O O O];

O=zeros(size(C));

C1=[C O;O O;O O;O O];
C2=[O O;O C;O O;O O];
C3=[O O;O O;O C;O O];
C4=[O O;O O;O O;O C];



AN=[A11 A12 A13 A14;A21 A22 A23 A24;A31 A32 A33 A34;A41 A42 A43 A44];
BN=[B1;B2;B3;B4];
CN=[C1 C2 C3 C4];
DN=zeros(4,4);

I2N=eye(2*n);
O2N=zeros(2*n);

F1=[I2N O2N O2N O2N;O2N O2N O2N O2N;O2N O2N O2N O2N;O2N O2N O2N O2N];
F2=[O2N O2N O2N O2N;O2N I2N O2N O2N;O2N O2N O2N O2N;O2N O2N O2N O2N];
F3=[O2N O2N O2N O2N;O2N O2N O2N O2N;O2N O2N I2N O2N;O2N O2N O2N O2N];
F4=[O2N O2N O2N O2N;O2N O2N O2N O2N;O2N O2N O2N O2N;O2N O2N O2N I2N];


S1=z(1);
S2=z(2);
S3=z(3);
S4=z(4);


F(1)=det([AN-S1*F1-S2*F2-S3*F3-S4*F4 BN;CN DN]);
F(2)=det([AN-S4*F1-S1*F2-S2*F3-S3*F4 BN;CN DN]);
F(3)=det([AN-S3*F1-S4*F2-S1*F3-S2*F4 BN;CN DN]);
F(4)=det([AN-S2*F1-S3*F2-S4*F3-S1*F4 BN;CN DN]);

 end
 

function [s0,m]=fixed_points(A,B,C,D)

 FP_real=[];
 tries=200;
 r=zeros(tries,4);
options = optimset('Display','off');
 for i=1:tries
 x0 = [rand*10^(randi([0 2])),rand*10^(randi([0 2])),rand*10^(randi([0 2])),rand*10^(randi([0 2]))];
 x = fsolve(@(z)solve_system(z,A,B,C,D),x0,options);
 r(i,:)=x;
 end

r=round(r,4);

[U I]=unique(r(:,1),'first');

FP_real=r(I,:);

s1=FP_real(:,1);
s2=FP_real(:,2);
s3=FP_real(:,3);
s4=FP_real(:,4);

positive_reals=true(size(s1,1),1);

for i=1:size(s1,1)
if (real(s1(i))<0||real(s2(i))<0||real(s3(i))<0||real(s4(i))<0)
positive_reals(i)=false;
end
end

s1=s1(positive_reals);
s2=s2(positive_reals);
s3=s3(positive_reals);
s4=s4(positive_reals);

FP_real=[s1,s2,s3,s4];

FP_imaj=[];
 %imaginary fixed points

tries=200;
r=zeros(tries,4);
options = optimset('Display','off');
for i=1:tries
 complex=100*rand;
 x0 = cplxpair([complex*exp(2*pi/4*1i),complex*exp(4*pi/4*1i),complex*exp(6*pi/4*1i),complex*exp(8*pi/4*1i)]);
x = fsolve(@(z)solve_system(z,A,B,C,D),x0,options);
r(i,:)=x;
end

r=round(r,4);

[U I]=unique(r(:,1),'first');

FP_imaj=r(I,:);

[theta,rho] = cart2pol(real(FP_imaj),imag(FP_imaj));
 theta=rad2deg(theta);
 round(sum(theta,2),0);
 closed_conj=(mod(sum(theta,2),180/4)==0);
 FP_imaj=FP_imaj(closed_conj,:);



 FP=[FP_real;FP_imaj];

 s1=FP(:,1);
 s2=FP(:,2);
 s3=FP(:,3);
 s4=FP(:,4);



 %clearing
 not_equal=~((s1==s2)|(s1==s3)|(s1==s4)|(s2==s3)|(s2==s4)|(s3==s4));

 s1=s1(not_equal);
 s2=s2(not_equal);
 s3=s3(not_equal);
 s4=s4(not_equal);

 s0=[s1,s2,s3,s4];
%remove unstable pairs
 stable_pairs=true(size(s1,1),1);
 n=size(A,2);
 E=eye(n);
 for i=1:size(s1,1)
 s0=[s1 s2 s3, s4];
 G=ss(A,B,C,D);
 Gm= Gm_generate(n,G,s0(i,:));
    
 if (~isstable(Gm))
     stable_pairs(i)=false;
 end
 end

 s1=s1(stable_pairs);
 s2=s2(stable_pairs);
 s3=s3(stable_pairs);
 s4=s4(stable_pairs);


 [U I]=unique(s1+s2+s3+s4,'first');

 s1=s1(I);
 s2=s2(I);
 s3=s3(I);
 s4=s4(I);

 s0=[s1,s2,s3,s4];
 m=size(s0,1);

end
 
function Gm = Gm_generate(n,G,sigma)
In=eye(n);
A = G.A;B = G.B;C = G.C;

Vm=[(sigma(1)*In-A)\B,(sigma(1)*In-A)\((sigma(2)*In-A)\B),(sigma(1)*In-A)\((sigma(2)*In-A)\((sigma(3)*In-A)\B)),(sigma(1)*In-A)\((sigma(2)*In-A)\((sigma(3)*In-A)\((sigma(4)*In-A)\B)))];
Wm=[(sigma(1)*In-A)'\C',(sigma(1)*In-A)'\((sigma(2)*In-A)'\C'),(sigma(1)*In-A)'\((sigma(2)*In-A)'\((sigma(3)*In-A)'\C')),(sigma(1)*In-A)'\((sigma(2)*In-A)'\((sigma(3)*In-A)'\((sigma(4)*In-A)'\C')))];


Am=(Wm'*Vm)\(Wm'*A*Vm);
Bm=(Wm'*Vm)\(Wm'*B); 
Cm=C*Vm;
Dm=0;
Gm=ss(Am,Bm,Cm,Dm);
end

function E = Error_calculate(n,G,Gm) 
In=eye(n);
% Im=eye(m);
A = G.A; B = G.B; C = G.C; D = G.D;
Am = Gm.A; Bm = Gm.B; Cm = Gm.C; Dm = Gm.D; 
H=G-Gm;
AH = H.A; BH = H.B; CH = H.C; DH = H.D; 
PH=lyap(AH,BH*BH');
P=lyap(A,B*B');
Pm=lyap(Am,Bm*Bm');
E= (CH*PH*CH')/(C*P*C');
E=sqrt(E);
end