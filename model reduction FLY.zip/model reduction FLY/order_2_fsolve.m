close all
 %clc 
 clc
 clear all
 example = input('Enter example number: ');
 switch example

 case 1
%EXAMPLE 1

%  numerator=[-2.924 -39.55 -97.53 -147.2];
%  denominator=[1 11.9584 43.91 73.68 44.38];

% numerator=[1 15 50];
% denominator=[1 5 33 79 50];

% numerator=[41 50 140];
% denominator=[1 11 111 110 100];

% numerator=[-2.9239 -39.5525 -97.5270 -147.1508];
% denominator=[1 11.9584 43.9119 73.6759 44.3821];

% numerator=[-1.2805 -6.2266 -12.8095 -9.3373];
% denominator=[1 3.1855 8.9263 12.2936 3.1987];
numerator=[-1.3452 -6.3453 -12.5676 -9.4563];
denominator=[1 3.2134 8.8765 12.3456 3.2167];

% numerator=[-1.3369 -4.8341 -47.5819 -42.7285];
% denominator=[1 17.0728 84.9908 122.4400 59.9309];
sys = tf(numerator,denominator)

 [A,B,C,D] = tf2ss(numerator,denominator);

 case 2
 %EXAMPLE 2
numerator=[-1.2805 -6.2266 -12.8095 -9.3373];
 denominator=[1 3.1855 8.9263 12.2936 3.1987];

 sys = tf(numerator,denominator)

 [A,B,C,D] = tf2ss(numerator,denominator);

 case 3
 %EXAMPLE 3

 numerator=[-1.3369 -4.8341 -47.5819 -42.7285];
 denominator=[1 17.0728 84.9908 122.4400 59.9309];

 sys = tf(numerator,denominator)

 [A,B,C,D] = tf2ss(numerator,denominator);

 case 4
 %EXAMPLE 4

 A=[0 0 0 -150;
 1 0 0 -245 ;
 0 1 0 -113 ;
 0 0 1 -19 ;];
 B=[4;1;0;0];
 C=[0 0 0 1];
 D=0;

[numerator,denominator] = ss2tf(A,B,C,0);
 sys = tf(numerator,denominator)


 case 5
 %EXAMPLE 5

%  numerator=[1 15 50];
%  denominator=[1 5 33 79 50];
numerator=[1 14 40];
denominator=[1 6 32 72 30];

 sys = tf(numerator,denominator)
 [A,B,C,D] = tf2ss(numerator,denominator);

 case 6
 %EXAMPLE 5

 numerator=[41 50 140];
 denominator=[1 11 111 110 100];

 sys = tf(numerator,denominator)

 [A,B,C,D] = tf2ss(numerator,denominator);

 end
 G=ss(A,B,C,D);
n=size(A,2);
 tic
 fprintf('Calculate fixed points.... \n')

 [s0,m]=fixed_points(A,B,C,D);

 for i=1:m
      Gm= Gm_generate(n,G,s0(i,:));
      E(i) = Error_calculate(n,G,Gm);
 end
[Em,d]=min(E);
Gm= Gm_generate(n,G,s0(d,:));

[numerator,denominator] = ss2tf(Gm.A,Gm.B,Gm.C,Gm.D);

 sysm = tf(numerator,denominator)
bode(G,Gm)
 toc
 
 function F = solve_system(z,A,B,C,D)

 n=size(A,2);

 O=zeros(n);
 I=eye(n);

 A11=[A 2*A;O A];
A12=[I O;I O];
 A21=[O O;I O];
A22=[A O;O A];

 O=zeros(size(B));

 B1=[B O;B O];
 B2=[O B;O O];

 O=zeros(size(C));

 C1=[C O;O O];
 C2=[O O;O C];


 AN=[A11 A12;A21 A22];
 BN=[B1;B2];
 CN=[C1 C2];
 DN=zeros(2,2);
 
 I2N=eye(2*n);
 O2N=zeros(2*n);

 F1=[I2N O2N;O2N O2N];
 F2=[O2N O2N;O2N I2N];

 S1=z(1);
 S2=z(2);

 F(1)=det([AN-S1*F1-S2*F2 BN;CN DN]);
 F(2)=det([AN-S2*F1-S1*F2 BN;CN DN]);

 end
 
 
 function [s0,m]=fixed_points(A,B,C,D)
  FP_real=[];
%  tries=2000;%%%%
 tries=200;%%%%
 r=zeros(tries,2);
 options = optimset('Display','off');
 for i=1:tries
    x0 = [rand*10^(randi([0 2])),rand*10^(randi([0 2]))];
    x = fsolve(@(z)solve_system(z,A,B,C,D),x0,options);
    r(i,:)=x;
 end

r=round(r,4);

 [U I]=unique(r(:,1),'first'); %repeated pairs cancelled
 
 FP_real=r(I,:);

 s1=FP_real(:,1);
 s2=FP_real(:,2);


 positive_reals=true(size(s1,1),1);% positive 

 for i=1:size(s1,1)
 if (real(s1(i))<0||real(s2(i))<0)
 positive_reals(i)=false;
 end
 end

 s1=s1(positive_reals);
 s2=s2(positive_reals);


 FP_real=[s1,s2];

 FP_imaj=[];
 %imaginary fixed points

%  tries=500;%%%%
tries=200;%%%%
 r=zeros(tries,2);
 options = optimset('Display','off');
 for i=1:tries
complex=100*rand;
 x0 = [complex*exp(2*pi/2*1i),complex*exp(4*pi/2*1i)];
 x = fsolve(@(z)solve_system(z,A,B,C,D),x0,options);
r(i,:)=x;
 end

r=round(r,4);

 [U I]=unique(r(:,1),'first');
FP_imaj=r(I,:);

 [theta,~] = cart2pol(real(FP_imaj),imag(FP_imaj)); %the two-dimensional Cartesian coordinate arrays x and y into polar coordinates
 theta=rad2deg(theta); 
 round(sum(theta,2),0)
 closed_conj=(mod(sum(theta,2),90)==0);
 FP_imaj=FP_imaj(closed_conj,:);



 FP=[FP_real;FP_imaj];

 s1=FP(:,1);
 s2=FP(:,2);


 %clearing
 not_equal=~(s1==s2);

 s1=s1(not_equal);
 s2=s2(not_equal);


 s0=[s1,s2];

 %remove unstable pairs

 stable_pairs=true(size(s1,1),1);
 n=size(A,2);
 E=eye(n);
 for i=1:size(s1,1)
 s0=[s1 s2];
  G=ss(A,B,C,D);
 Gm= Gm_generate(n,G,s0(i,:));

 if (~isstable(Gm))
         stable_pairs(i)=false;
 end
 end

 s1=s1(stable_pairs);
 s2=s2(stable_pairs);
 


 [U I]=unique(s1+s2,'first');

 s1=s1(I);
 s2=s2(I);


 s0=[s1,s2];
 m=size(s0,1);
 end
 function Gm = Gm_generate(n,G,sigma)
In=eye(n); 
A = G.A;B = G.B;C = G.C;

for i=1:2 
        Vm(:,i)=(sigma(i)*In-A)\B; 
        Wm(:,i)=(conj(sigma(i))*In-A')\C';
 end

Am=(Wm'*Vm)\(Wm'*A*Vm);
Bm=(Wm'*Vm)\(Wm'*B); 
Cm=C*Vm;
Dm=0;
Gm=ss(Am,Bm,Cm,Dm);
end

function E = Error_calculate(n,G,Gm) 
In=eye(n);
A = G.A; B = G.B; C = G.C; D = G.D;
Am = Gm.A; Bm = Gm.B; Cm = Gm.C; Dm = Gm.D; 
H=G-Gm;
AH = H.A; BH = H.B; CH = H.C; DH = H.D; 
PH=lyap(AH,BH*BH');
P=lyap(A,B*B');
Pm=lyap(Am,Bm*Bm');
E= (CH*PH*CH')/(C*P*C');
E=sqrt(E);
end
 
