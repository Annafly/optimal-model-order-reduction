clear;
clear all
clc
%input G(s)
 
%system 1
% A=[0 0 0 -150;
% 1 0 0 -245 ;
% 0 1 0 -113 ;
% 0 0 1 -19]; 
% B=[4;1;0;0];
% C=[0 0 0 1];
% D=0;
% A=[0  0 -150;
% 1  0 -245 ;
% 0  1 -19]; 
% B=[4;1;0];
% C=[0 0 1];
% D=0;
% % %system 2
% numerator=[1  50];
% denominator=[1 5 79 50];
% denominator=[1 15 50];
% numerator=[1 15 50];
% denominator=[1 5 33 79 50];
% numerator=[1  10];
% denominator=[1 15 20];
% numerator=[1 14 40];
% denominator=[1 6 32 72 30];
%system 3
% numerator=[41 50 140];
% denominator=[1 11  110 100];
% numerator=[41 50 ];
% denominator=[1 11  100];
% numerator=[41 50 140];
% denominator=[1 11 111 110 100];
%system 4
% numerator=[-2.9239 -39.5525 -97.5270 -147.1508];
% denominator=[1 11.9584 43.9119 73.6759 44.3821];

%system 5
% numerator=[-1.2805 -6.2266 -12.8095 -9.3373];
% denominator=[1 3.1855 8.9263 12.2936 3.1987];
numerator=[-1.3452 -6.3453 -12.5676 -9.4563];
denominator=[1 3.2134 8.8765 12.3456 3.2167];
% % numerator=[-1.2805 -6.2266 -9.3373];
% % denominator=[1 3.1855 8.9263 3.1987];
%system 6
% numerator=[-1.3369 -4.8341 -47.5819 -42.7285];
% denominator=[1 17.0728 84.9908 122.4400 59.9309];


sys = tf(numerator,denominator); 
[A,B,C,D] = tf2ss(numerator,denominator); 
G=ss(A,B,C,D);

n=size(A);m=2;
In=eye(n);Im=eye(m);


%Construct new A,B,C,D
O=zeros(n);
I=eye(n);
A11=[A 2*A;O A];
A12=[I O;I O];
A21=[O O;I O];
A22=[A O;O A];

O=zeros(size(B));
B1=[B O;B O];
B2=[O B;O O];

O=zeros(size(C));
C1=[C O;O O];
C2=[O O;O C];

A_new=[A11,A12;A21,A22];
B_new=[B1;B2];
BO=zeros(size(B_new));
C_new=[C1,C2];
CO=zeros(size(C_new));
D_new=[0 0; 0 0];
DO=zeros(size(D_new));

I2N=eye(2*n);
O2N=zeros(2*n);
F1=[I2N O2N;O2N O2N];
F2=[O2N O2N;O2N I2N];

A10=[A_new,B_new;C_new,D_new];
A11=[-F1,BO;CO,DO];
A12=[-F2,BO;CO,DO];

A20=[A_new,B_new;C_new,D_new];
A21=[-F2,BO;CO,DO];
A22=[-F1,BO;CO,DO];
%% check the result of s1 and s2 in multi-eigenvalue problem
syms s1 s2;
 F(1)=det([A10+s1*A11+s2*A12]);
 F(2)=det([A20+s1*A21+s2*A22]);

[ss1,ss2]=solve(F,[s1,s2]);
ss1=double(ss1);
ss2=double(ss2);

%%
Delta0 = kron(A11,A22) - kron(A12,A21);
Delta1 = kron(A12,A20) - kron(A10,A22);
Delta2 = kron(A10,A21) - kron(A11,A20); 
lamta=multi_egi(Delta0,Delta1)
mu=multi_egi(Delta0,Delta2)

function lamta=multi_egi(Delta0,Delta1)
[U0,S0,V0] = svd(Delta0);
r=rank(Delta0);


AH=U0'*Delta1*V0;
s=size(Delta1,1);
AHC = mat2cell(AH,[r s-r],[r s-r]);
A11H=AHC{1,1};
A12H=AHC{1,2};
A21H=AHC{2,1};
A22H=AHC{2,2};

sig = mat2cell(S0,[r s-r],[r s-r]);
sig1=sig{1,1};

A11HH=inv(sig1)*A11H;
A12HH=inv(sig1)*A12H;

[U2,S2,V2] = svd(A22H);
r2=rank(A22H);

A12HHH=A12HH*V2;
A21HHH=U2'*A21H;

h1=size(A12HHH,1);
l1=size(A12HHH,2);
A12HHHC = mat2cell(A12HHH,[h1],[r2 l1-r2]);
A12x=A12HHHC{1,1};
A13x=A12HHHC{1,2};

h2=size(A21HHH,1);
l2=size(A21HHH,2);
A21HHHC = mat2cell(A21HHH,[r2 h2-r2],[l2]);
A21x=A21HHHC{1,1};
A31x=A21HHHC{2,1};

sigx = mat2cell(S2,[r2 h2-r2],[r2 l1-r2]);
sigx2=sigx{1,1};

AS=A11HH-A12x*inv(sigx2)*A21x;
BS=A13x;
CS=A31x;
DS=zeros(size(CS,1),size(BS,2));
sys1=ss(AS,BS,CS,DS);
tol=1.0d-5;
lamta=tzero(sys1,tol);
%  lamta=tzero(sys1);
end
% sl=size(lamta,1);
% for i= 1:sl
%     lamta(i)
% [V3,D3]=eig(A10+lamta(i)*A11,-A12)
% [V4,D4]=eig(A20+lamta(i)*A21,-A22)
% end