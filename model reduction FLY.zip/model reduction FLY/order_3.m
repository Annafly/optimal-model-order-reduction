
close all
 clc
 clear all
 example = input('Enter example number: ');
 switch example

 case 1
%EXAMPLE 1

%  numerator=[-2.9239 -39.5525 -97.5270 -147.1508];
%  denominator=[1 11.9584 43.9119 73.6759 44.3821];
 numerator=[-2.924 -39.55 -97.53 -147.2];
 denominator=[1 11.96 43.91 73.68 44.38];

sys = tf(numerator,denominator)

 [A,B,C,D] = tf2ss(numerator,denominator);

 case 2
 %EXAMPLE 2
% numerator=[-1.2805 -6.2266 -12.8095 -9.3373];
%  denominator=[1 3.1855 8.9263 12.2936 3.1987];
numerator=[4.899 45.18 167.8 342 407.2 290.1 141.5 40.85];
 denominator=[1 9.982 43 111.6 195.6 244.6 215.3 114.3 25.91];

 sys = tf(numerator,denominator)

 [A,B,C,D] = tf2ss(numerator,denominator);

 case 3
 %EXAMPLE 3
numerator=[0.385 4.683 144.1 -116.3 -82.3];
 denominator=[1 11.6 252.6 751.1 534 94.56];
 
%  numerator=[-1.3369 -4.8341 -47.5819 -42.7285];
%  denominator=[1 17.0728 84.9908 122.4400 59.9309];

 sys = tf(numerator,denominator)

 [A,B,C,D] = tf2ss(numerator,denominator);
 

 case 4
 %EXAMPLE 4

%  A=[0 0 0 -150;
%  1 0 0 -245 ;
%  0 1 0 -113 ;
%  0 0 1 -19 ;];
%  B=[4;1;0;0];
%  C=[0 0 0 1];
% 
% [numerator,denominator] = ss2tf(A,B,C,0);
%  sys = tf(numerator,denominator)

 numerator=[1.802 11.05 33.83 69.71 104.6 117.4 101.7 68.01 32.89 10.27 1.766 0.1201];
 denominator=[1 6.8 23.48 54.89 93.98 121.2 120.4 92.46 53.27 21.7 5.742 0.8652 0.05496];

 sys = tf(numerator,denominator)

 [A,B,C,D] = tf2ss(numerator,denominator);

 case 5
 %EXAMPLE 5

%  numerator=[1 15 50];
%  denominator=[1 5 33 79 50];

%  numerator=[-0.1463 0.004163 2.325 6.701 6.717 2.325];
%  denominator=[1 4.768 17.53 41.44 46.64 22.95 3.949];

 numerator=[-0.1356 0.003986 2.435 6.626 6.543 2.542];
 denominator=[1 4.468 16.36 36.45 43.56 25.35 3.268];

 sys = tf(numerator,denominator)
 [A,B,C,D] = tf2ss(numerator,denominator);

 case 6
 %EXAMPLE 5

%  numerator=[41 50 140];
%  denominator=[1 11 111 110 100];
%  numerator=[-5.738 -19.65 -25.09 -12.59 -2.002];
%  denominator=[1 3.925 6.088 4.323 1.319 0.1191];
  numerator=[-5.456 -16.43 -24.34 -15.53 -1.999];
 denominator=[1 4.012 6.123 4.435 1.425 0.1256];
 sys = tf(numerator,denominator)

 [A,B,C,D] = tf2ss(numerator,denominator);

 end
 G=ss(A,B,C,D);
n=size(A,2);

 
 tic
 fprintf('Calculate fixed points.... \n')

 [s0,m]=fixed_points(A,B,C,D)


for i=1:m
    Gm= Gm_generate(n,G,s0(i,:));
    E(i) = Error_calculate(n,G,Gm);
end
[Em,d]=min(E);
Gm= Gm_generate(n,G,s0(d,:));

[numerator,denominator] = ss2tf(Gm.A,Gm.B,Gm.C,Gm.D);

 sysm = tf(numerator,denominator)


bode(G,'r',Gm,'b--')

 toc





function F = solve_system(z,A,B,C,D)

 n=size(A,2);

 O=zeros(n);
 I=eye(n);

 A11=[A 2*A;O A]; A12=[I O;I O]; A13=[O O;O O];
A21=[O O;I O]; A22=[A O;O A]; A23=[I O;O O];
 A31=[O O;O O]; A32=[O O;O I]; A33=[A O;O A];

 O=zeros(size(B));

 B1=[B O O;B O O];
 B2=[O B O;O O O];
 B3=[O O B;O O O];

 O=zeros(size(C));

 C1=[C O;O O;O O];
 C2=[O O;O C;O O];
 C3=[O O;O O;O C];

%   D=[zeros(size(CN,1),size(BN,2)) zeros(size(CN,1),size(BN,2)); zeros(size(CN,1),size(BN,2)) zeros(size(CN,1),size(BN,2))];

 AN=[A11 A12 A13;A21 A22 A23;A31 A32 A33];
BN=[B1;B2;B3];
CN=[C1 C2 C3];
 DN=zeros(3,3);
 
 I2N=eye(2*n);
 O2N=zeros(2*n);

F1=[I2N O2N O2N;O2N O2N O2N;O2N O2N O2N];
 F2=[O2N O2N O2N;O2N I2N O2N;O2N O2N O2N];
F3=[O2N O2N O2N;O2N O2N O2N;O2N O2N I2N];

S1=z(1);
S2=z(2);
S3=z(3);

F(1)=det([AN-S1*F1-S2*F2-S3*F3 BN;CN DN]);
F(2)=det([AN-S3*F1-S1*F2-S2*F3 BN;CN DN]);
 F(3)=det([AN-S2*F1-S3*F2-S1*F3 BN;CN DN]);

end

function [s0,m]=fixed_points(A,B,C,D)

 FP_real=[];
% tries=2000;%%%%
tries=200;%%%%
 r=zeros(tries,3);
 options = optimset('Display','off');
 for i=1:tries
    x0 = [rand*10^(randi([0 2])),rand*10^(randi([0 2])),rand*10^(randi([0 2]))];
    x = fsolve(@(z)solve_system(z,A,B,C,D),x0,options);
    r(i,:)=x;
 end

r=round(r,4);

 [U I]=unique(r(:,1),'first'); %repeated pairs cancelled
 
 FP_real=r(I,:);

 s1=FP_real(:,1);
 s2=FP_real(:,2);
 s3=FP_real(:,3);

 positive_reals=true(size(s1,1),1);% positive 

 for i=1:size(s1,1)
 if (real(s1(i))<0||real(s2(i))<0||real(s3(i))<0)
 positive_reals(i)=false;
 end
 end

 s1=s1(positive_reals);
 s2=s2(positive_reals);
 s3=s3(positive_reals);

 FP_real=[s1,s2,s3];

 FP_imaj=[];
 %imaginary fixed points

%  tries=500;%%%%
tries=200;%%%%
 r=zeros(tries,3);
 options = optimset('Display','off');
 for i=1:tries
complex=100*rand;
 x0 = [complex*exp(2*pi/3*1i),complex*exp(4*pi/3*1i),complex*exp(6*pi/3*1i)];
 x = fsolve(@(z)solve_system(z,A,B,C,D),x0,options);
r(i,:)=x;
 %fprintf('%d/%d \n',i,size(r,1))
 end

r=round(r,4);

 [U I]=unique(r(:,1),'first');
FP_imaj=r(I,:);

 [theta,~] = cart2pol(real(FP_imaj),imag(FP_imaj)); %the two-dimensional Cartesian coordinate arrays x and y into polar coordinates
 theta=rad2deg(theta); 
 round(sum(theta,2),0)
 closed_conj=(mod(sum(theta,2),60)==0);
 FP_imaj=FP_imaj(closed_conj,:);



 FP=[FP_real;FP_imaj];

 s1=FP(:,1);
 s2=FP(:,2);
 s3=FP(:,3);

 %clearing
 not_equal=~((s1==s2)|(s1==s3)|(s2==s3));

 s1=s1(not_equal);
 s2=s2(not_equal);
 s3=s3(not_equal);

 s0=[s1,s2,s3];

 %remove unstable pairs

 stable_pairs=true(size(s1,1),1);
 n=size(A,2);
 E=eye(n);
 for i=1:size(s1,1)
 s0=[s1 s2,s3];
  G=ss(A,B,C,D);
 Gm= Gm_generate(n,G,s0(i,:));

 if (~isstable(Gm))
         stable_pairs(i)=false;
 end
 end

 s1=s1(stable_pairs);
 s2=s2(stable_pairs);
 s3=s3(stable_pairs);


 [U I]=unique(s1+s2+s3,'first');

 s1=s1(I);
 s2=s2(I);
 s3=s3(I);

 s0=[s1,s2,s3];
 m=size(s0,1);

end



function Gm = Gm_generate(n,G,sigma)
In=eye(n);
A = G.A;B = G.B;C = G.C;

% Vm=[(sigma(1)*In-A)\B,(sigma(1)*In-A)\((sigma(2)*In-A)\B),(sigma(1)*In-A)\((sigma(2)*In-A)\((sigma(3)*In-A)\B))];
% Wm=[(sigma(1)*In-A)'\C',(sigma(1)*In-A)'\((sigma(2)*In-A)'\C'),(sigma(1)*In-A)'\((sigma(2)*In-A)'\((sigma(3)*In-A)'\C'))];

for i=1:3 
        Vm(:,i)=(sigma(i)*In-A)\B; 
        Wm(:,i)=(conj(sigma(i))*In-A')\C';
 end

Am=(Wm'*Vm)\(Wm'*A*Vm);
Bm=(Wm'*Vm)\(Wm'*B); 
Cm=C*Vm;
Dm=0;
Gm=ss(Am,Bm,Cm,Dm);
end

function E = Error_calculate(n,G,Gm) 
In=eye(n);
A = G.A; B = G.B; C = G.C; D = G.D;
Am = Gm.A; Bm = Gm.B; Cm = Gm.C; Dm = Gm.D; 
H=G-Gm;
AH = H.A; BH = H.B; CH = H.C; DH = H.D; 
PH=lyap(AH,BH*BH');
P=lyap(A,B*B');
Pm=lyap(Am,Bm*Bm');
E= (CH*PH*CH')/(C*P*C');
E=sqrt(E);
end
 
 